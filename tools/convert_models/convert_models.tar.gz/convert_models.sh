#!/bin/bash

fstconvert ./models/HCLG.fst ./models/HCLG_Vector.fst

./convert_models.bin --frame-subsampling-factor=3 --config=./models/conf/online.conf ./models/words.txt ./models/final.mdl ./models/HCLG_Vector.fst ./models/models_headers
